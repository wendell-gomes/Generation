package Aula7Ex;

import Aula7Ex.Pessoa;
import Aula7Ex.Fornecedor;

public class Teste {
	public static void main(String args[]) {
		Pessoa wendell = new Pessoa("Wendell","Rua","12225354");
		Pessoa joao = new Fornecedor("Jo�o","Rua","12225354",1000,800,1000-800);
		
		
		System.out.println("\nNome: ");
		System.out.println(wendell.getNome());
		System.out.println("\nEndere�o: ");
		System.out.println(wendell.getEndere�o());
		System.out.println("\nTelefone: ");
		System.out.println(wendell.getTelefone());
		
		
		System.out.println("\nNome: ");
		System.out.println(joao.getNome());
		System.out.println("\nEndere�o: ");
		System.out.println(joao.getEndere�o());
		System.out.println("\nTelefone: ");
		System.out.println(joao.getTelefone());
		System.out.println("\nValor da diferen�a: ");
		System.out.println(((Fornecedor) joao).getObtersaldo());
		
	}
}
