package Aula7Ex;

import Aula7Ex.Pessoa;

public class Fornecedor extends Pessoa {
	private float valorCredito;
	//(correspondente ao cr�dito m�ximo atribu�do ao fornecedor)
	private float valorDivida;
	// (montante da d�vida para com o fornecedor).
	private float obtersaldo;
	public Fornecedor(String nome, String endere�o, String telefone, float valorCredito, float valorDivida, float obtersaldo)
	{
		super(nome,endere�o,telefone);
		this.valorCredito = valorCredito;
		this.valorDivida = valorDivida;
		this.obtersaldo = obtersaldo;
		
	}

	public float getObtersaldo() {
		return obtersaldo;
	}

	public void setObtersaldo(float obtersaldo) {
		this.obtersaldo = obtersaldo;
	}

	public float getValorCredito() {
		return valorCredito;
	}

	public void setValorCredito(float valorCredito) {
		this.valorCredito = valorCredito;
	}

	public float getValorDivida() {
		return valorDivida;
	}

	public void setValorDivida(float valorDivida) {
		this.valorDivida = valorDivida;
	}


}