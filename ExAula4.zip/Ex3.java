package Aula4;

import java.util.Scanner;

public class Ex3 {
	public static void main(String[] args) {
		
		
		int[] [] matriz = new int [4][6];
		int[] [] matriz2 = new int [4][6];
		int[] [] matriz3 = new int [4][6];
		int[] [] matriz4 = new int [4][6];
		
		

		Scanner ler = new Scanner (System.in);
	
		System.out.println("Escreva os valores da Matrix N1[4][6]\n");
		
		for (int linha=0 ; linha < 4 ; linha++) {
			for(int coluna = 0; coluna < 6 ; coluna ++) {
				System.out.printf("Insira o elemento M[%d][%d]: ",linha+1,coluna+1);
				matriz[linha][coluna]=ler.nextInt();
			}
		}


		System.out.println("Escreva os valores da Matrix N2[4][6]\n");
	
		for (int linha=0 ; linha < 4 ; linha++) {
			for(int coluna = 0; coluna < 6 ; coluna ++) {
				System.out.printf("Insira o elemento M[%d][%d]: ",linha+1,coluna+1);
				matriz2[linha][coluna]=ler.nextInt();
			}
		}

	
	
		System.out.println("\n");
	
		for (int linha=0 ; linha < 4 ; linha++) {
			for(int coluna = 0; coluna < 6 ; coluna ++) {
				matriz3 [linha][coluna] = matriz[linha][coluna] + matriz2 [linha][coluna];
			}
		}
	
		System.out.println("\nA soma da matriz N1 e N2 foi: \n");
		for (int linha=0 ; linha < 4 ; linha++) {
			for (int coluna = 0; coluna < 6 ; coluna ++) {
				System.out.printf("\t %d \t",matriz3[linha][coluna]);
				}
				System.out.println();
		}
	
	
		
		System.out.println("\n");
	
		for (int linha=0 ; linha < 4 ; linha++) {
			for(int coluna = 0; coluna < 6 ; coluna ++) {
				matriz4 [linha][coluna] = matriz[linha][coluna] - matriz2 [linha][coluna];
			}
		}
	
	
		
		System.out.println("\nA diferen�a entre a matriz N1 e N2 �: \n");
	for (int linha=0 ; linha < 4 ; linha++) {
		for (int coluna = 0; coluna < 6 ; coluna ++) {
			System.out.printf("\t %d \t",matriz4[linha][coluna]);
			}
			System.out.println();
		}
	}
}
