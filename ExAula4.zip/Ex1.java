package Aula4;

import java.util.Scanner;

public class Ex1 {
	public static void main(String[] args) {
		int nota,n=5,notamaior; 
		int vet[] = new int[n],soma=0;
		
		
		Scanner ler = new Scanner(System.in);
		
		for(nota=0;nota<5;nota++)
		{
			System.out.printf("Entre com a %2d� nota de %d: ",(nota+1),n);
			vet[nota] = ler.nextInt();
		}

		int menor=vet[0],maior=vet[0];
		for(nota=0;nota<n;nota++)
		{
			soma = soma + vet[nota];
			if(vet[nota]<menor)
			{
				menor = vet[nota];
			}
			
			if(vet[nota]>maior)
			{
				maior = vet[nota];
			}
		}

		for(nota=0;nota<n;nota++)
		{
			if(vet[nota] == maior)
			{
				System.out.printf("Vet[%d] = %2d <-- Esta � o maior nota das que foram apresentadas \n",nota,vet[nota]);
			}

			else
			{
				System.out.printf("Vet[%d] = %2d\n",nota,vet[nota]);
			}
		}
	}
}
