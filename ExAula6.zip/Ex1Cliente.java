package Aula6;

public class Ex1Cliente {
	private String primeiroNome;
	private String endere�o;
	private int cpf;
	
	public Ex1Cliente (String primeiro, String rua)
	{
		primeiroNome = primeiro;
		endere�o = rua;
	}
	public Ex1Cliente (int cpf)
	{
		this.cpf = cpf;

	}
	
	public String getNomeeEndere�o()
	{
		String NomeeEndere�o = primeiroNome+" "+endere�o;
		return NomeeEndere�o;
	}
	public int getNumeroCPF()
	{
		int NumeroCPF = cpf;
		return NumeroCPF;
	}
	
}
