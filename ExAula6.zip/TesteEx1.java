package Aula6;


public class TesteEx1 {
	public static void main (String args [])
	{
		Ex1Cliente cliente1 = new Ex1Cliente("Jo�o","Rua");
		Ex1Cliente cpfcliente = new Ex1Cliente(1111111111);
		System.out.println(cliente1.getNomeeEndere�o());
		System.out.println("\nCPF: "+cpfcliente.getNumeroCPF());
	
	}
}
