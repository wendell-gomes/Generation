package Aula6;

public class Paciente {
	private String Nome;
	private String TipoSangue;
	private String Queixa;
	private int AnoNasc;
	
	public Paciente(String Nome,String Sangue,String Queixa,int AnoNasc) {
		this.Nome = Nome;
		this.TipoSangue = Sangue;
		this.Queixa = Queixa;
		this.AnoNasc =  AnoNasc;
	}
	public void idade(int conta)
	{
		conta = 2021 - AnoNasc;
	}
	public void imprimirInfo()
	{
		AnoNasc = 2021 - AnoNasc;
		System.out.println(Nome+", possui o tipo sangu�neo: "+TipoSangue+" com os sintomas de: "+Queixa+" e possui: "+AnoNasc+" Anos");
	}
	
	
	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public String getTipoSangue() {
		return TipoSangue;
	}

	public void setTipoSangue(String tipoSangue) {
		TipoSangue = tipoSangue;
	}

	public String getQueixa() {
		return Queixa;
	}

	public void setQueixa(String queixa) {
		Queixa = queixa;
	}

	public int getAnoNasc() {
		return AnoNasc;
	}

	public void setAnoNasc(int anoNasc) {
		AnoNasc = anoNasc;
	}
	
	
}