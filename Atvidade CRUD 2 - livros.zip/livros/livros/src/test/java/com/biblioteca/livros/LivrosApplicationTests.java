package com.biblioteca.livros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
