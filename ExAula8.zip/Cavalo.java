package Aula8Ex;

public class Cavalo extends Animal{
	private String hinninin;
	private String devecorrer;
	
	
	public Cavalo()
	{
		
	}	
	
	
	public String getHinninin() {
		return hinninin;
	}
	public void setHinninin(String hinninin) {
		this.hinninin = hinninin;
	}
	public String getDevecorrer() {
		return devecorrer;
	}
	public void setDevecorrer(String devecorrer) {
		this.devecorrer = devecorrer;
	}
	
	
	public String getNome()
	{
		return "\nAnimal:"+super.getNome()+"\nIdade:"+super.getIdade()+"\nBarulho: "+this.getHinninin()+"\nForma de se locomover: "+this.getDevecorrer();	
	}


}
