package Aula8Ex;

public class Pregui�a extends Animal{
	private String mimir;
	private String devesubiremarvore;
	
	public Pregui�a()
	{
		
	}
	
	
	
	public String getMimir() {
		return mimir;
	}
	public void setMimir(String mimir) {
		this.mimir = mimir;
	}
	public String getDevesubiremarvore() {
		return devesubiremarvore;
	}
	public void setDevesubiremarvore(String devesubiremarvore) {
		this.devesubiremarvore = devesubiremarvore;
	}
	
	
	public String getNome()
	{
		return "\nAnimal:"+super.getNome()+"\nIdade:"+super.getIdade()+"\nBarulho: "+this.getMimir()+"\nForma de se locomover: "+this.getDevesubiremarvore();	
	}

}
