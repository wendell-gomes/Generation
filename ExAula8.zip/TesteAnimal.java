package Aula8Ex;


public class TesteAnimal {
	public static void main (String args []) {
		Cachorro cachorro = new Cachorro();
		cachorro.setNome(" Dogzin");
		cachorro.setIdade(" 3 Anos");
		cachorro.setAuau(" AUAUAUAU");
		cachorro.setDevecorrer(" Correndo");
		
		Cavalo cavalo = new Cavalo();
		cavalo.setNome(" Cavalin");
		cavalo.setIdade(" 5 Anos");
		cavalo.setHinninin(" Hinn in in");
		cavalo.setDevecorrer(" Correndo");
		
		Pregui�a pregui�a = new Pregui�a();
		pregui�a.setNome(" Preguizinha");
		pregui�a.setIdade(" 10 Anos");
		pregui�a.setMimir(" Vou ir mimir");
		pregui�a.setDevesubiremarvore(" Subir em �rvore");
		
		Animal[] animais = new Animal[3];
		animais [0]=cachorro;
		animais [1]=cavalo;
		animais [2]=pregui�a;
		
		
		for(Animal bichos :animais)
		{
			System.out.println(bichos.getNome());
			
		}
		
	}
}
