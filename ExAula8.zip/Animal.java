package Aula8Ex;

public class Animal {
	
		private String nome;
		private String idade;
		
		public String getNome() {
			return nome;
		}
		public void setNome(final String nome) {
			this.nome = nome;
		}
		public String getIdade() {
			return idade;
		}
		public void setIdade(final String idade) {
			this.idade = idade;
		}
	
}
