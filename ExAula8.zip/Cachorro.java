package Aula8Ex;


public class Cachorro extends Animal  {
	private String auau;
	private String devecorrer;
	
	public Cachorro()
	{
		
	}

	public String getAuau() {
		return auau;
	}

	public void setAuau(String auau) {
		this.auau = auau;
	}
	
	
	public String getDevecorrer() {
		return devecorrer;
	}

	public void setDevecorrer(String devecorrer) {
		this.devecorrer = devecorrer;
	}
	
	
	public String getNome()
	{
		return "\nAnimal:"+super.getNome()+"\nIdade:"+super.getIdade()+"\nBarulho: "+this.getAuau()+"\nForma de se locomover: "+this.getDevecorrer();	
	}
	
}
