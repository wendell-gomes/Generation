package Aula2;

import java.util.Scanner;

public class Ex1 {
	public static void main (String args[])
	
	{
	int num1,num2,num3;
	
	try (Scanner ler = new Scanner(System.in)) {
		System.out.println("Entre com o numero 1:");
		num1 = ler.nextInt();
		System.out.println("Entre com o numero 2:");
		num2 = ler.nextInt();
		System.out.println("Entre com o numero 3:");
		num3 = ler.nextInt();
	}
	
	if(num1>num2 && num1>num3)
	{
		System.out.println("\nO n�mero 1 � o maior");
	}
	else if (num2>num1 && num2>num3)
	{
		System.out.println("\nO n�mero 2 � o maior");
	}
	else if (num3>num1 && num3>num1)
	{
		System.out.println("\nO n�mero 3 � o maior");
	}
	else 
	{
		System.out.println("\nFora do par�metro");
	}
		
	}		
}
