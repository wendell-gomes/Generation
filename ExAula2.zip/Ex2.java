package Aula2;

import java.util.Scanner;

public class Ex2 {
	public static void main (String args[])
	
	{
	int num1,num2,num3;
	
	try (Scanner ler = new Scanner(System.in)) {
		System.out.println("Entre com o numero 1:");
		num1 = ler.nextInt();
		System.out.println("Entre com o numero 2:");
		num2 = ler.nextInt();
		System.out.println("Entre com o numero 3:");
		num3 = ler.nextInt();
	}
	
	if(num1>num2 && num1>num3 && num2>num3)
	{
		System.out.println("\nA ordem crescente �: ");
		System.out.println("\nPrimeiro n�mero: "+num1);
		System.out.println("\nSegundo n�mero: "+num2);
		System.out.println("\nTerceiro n�mero: "+num3);
	}
	else if (num1>num2 && num1>num2 && num3>num2)
	{
		System.out.println("\nA ordem crescente �: ");
		System.out.println("\nPrimeiro n�mero: "+num1);
		System.out.println("\nTerceiro n�mero: "+num3);
		System.out.println("\nSegundo n�mero: "+num2);
	}
	else if (num2>num1 && num2>num3 && num1>num3)
	{
		System.out.println("\nA ordem crescente �: ");
		System.out.println("\nPSegundo n�mero: "+num2);
		System.out.println("\nPrimeiro n�mero: "+num1);
		System.out.println("\nTerceiro n�mero: "+num3);
	}
	else if (num2>num1 && num2>num3 && num3>num1)
	{
		System.out.println("\nA ordem crescente �: ");
		System.out.println("\nPSegundo n�mero: "+num2);
		System.out.println("\nTerceiro n�mero: "+num3);
		System.out.println("\nTPrimeiro n�mero: "+num1);

	}
	else if (num3>num1 && num3>num2 && num1>num2)
	{
		System.out.println("\nA ordem crescente �: ");
		System.out.println("\nTerceiro n�mero: "+num3);
		System.out.println("\nPrimeiro n�mero: "+num1);
		System.out.println("\nSegundo n�mero: "+num2);
	}

	else if(num3>num1 && num3>num2 && num2>num1)
	{
		System.out.println("\nA ordem crescente �: ");
		System.out.println("\nTerceiro n�mero: "+num3);
		System.out.println("\nSegundo n�mero: "+num2);
		System.out.println("\nPrimeiro n�mero: "+num1);
	}
	}		
}