package Aula3;

import java.util.Scanner;

public class Ex3 {

	public static void main(String[] args) {
		try (// TODO Auto-generated method stub
		Scanner ler = new Scanner (System.in)) {
			int idade,cont21=0,cont50=0;
			
			System.out.printf("\nEntre com a sua idade: ");
			idade = ler.nextInt();
			while (idade!=-99)
			{

				System.out.printf("\nEntre com a sua idade: ");
				idade = ler.nextInt();
				if (idade<=21)
				{
					cont21++;
				}
				else if (idade>=50)
				{
					cont50++;
				}
				
				
			}
			System.out.printf("Pessoas com menos de 21 s�o %d, e pessoas com mais de 50 s�o %d",cont21,cont50);	
		}
	
	}
}