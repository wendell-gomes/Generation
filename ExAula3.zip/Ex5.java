package Aula3;

import java.util.Scanner;

public class Ex5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Scanner ler =  new Scanner(System.in);
		int num,soma=0;
		
		
		
		do
		{
			System.out.println("Entre com o n�mero: ");
			num = ler.nextInt();
			if(num==0)
			{
				System.out.println("Loop finalizado");
			}
			else
			{
				soma = soma + num;
			}
		}while(num!=0);
		System.out.println("\nA soma dos n�meros digitados foi: "+soma);
	}
}


