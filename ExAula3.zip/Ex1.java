package Aula3;

public class Ex1 {
	public static void main(String[] args) {
		int x;
		
		for(x=1000;x<=1999;x++)
		{
			if(x%11==5)
			{
				System.out.printf("\nOs n�meros dividos por 11 que o resto � 5 �: %d",x);
			}	
		}
	}
}