package Aula9Ex;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

public class Ex1 {
	public static void main(String [] args) throws InterruptedException
	{
		new Thread();
		Collection < String > roupas = new ArrayList();
		roupas.add("Camisas");
		roupas.add("Blusas");
		roupas.add("Shorts");
		roupas.add("Cal�as");
		

		Collection < String > calcados = new ArrayList();
		
		calcados.add("Tenis Masculino");
		calcados.add("Tenis Femininos");
		calcados.add("Sandalias");
		calcados.add("Sociais");
		
		System.out.println("Roupas que cont�m na loja: "+roupas);
		
		Thread.sleep(1000);
		
		System.out.println("Cal�ados que cont�m na loja: "+calcados);
		
		Thread.sleep(1000);
		
		System.out.println("Perd�o Jo�o, o ultimo modelo de camisa foi vendido.");
		roupas.remove("Camisas");
		
		Thread.sleep(3000);
		
		System.out.println("S� temos os seguintes produtos disponiveis agora: "+roupas);
		
		roupas.add("Camisas rosas");
		roupas.add("Camisas laranjas");
		roupas.add("Camisas brancas");
		roupas.add("Camisas pretas");
		
		Thread.sleep(3000);
		
		System.out.println("Jo�o, temos uma not�cia boa, chegou mais camisas, irei te falar a lista atualizada:");
		
		Thread.sleep(2000);
		
		System.out.println(roupas);
		

	}
}
